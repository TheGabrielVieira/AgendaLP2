#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contatos.h"

// Funções para exibir itens da agenda
void listarContatos(struct Contato agendaContatos[], int numContatos) {
    printf("\nLista de Contatos:\n");
    for (int i = 0; i < numContatos; i++) {
        printf("Nome: %s\n", agendaContatos[i].nome);
        printf("Telefone: %s\n", agendaContatos[i].telefone);
        printf("\n");
    }
}

// Funções para adicionar itens à agenda
void adicionarContato(struct Contato agendaContatos[], int *numContatos) {
    if (*numContatos < 50) {
        printf("Digite o nome do contato: ");
        fflush(stdin);
        scanf(" %[^\n]s", agendaContatos[*numContatos].nome);
        printf("Digite o telefone do contato: ");
        fflush(stdin);
        scanf(" %[^\n]s", agendaContatos[*numContatos].telefone);
        (*numContatos)++;
    } else {
        printf("A agenda de contatos está cheia.\n");
    }
}
