#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "compromissos.h"

void adicionarCompromisso(struct Compromisso agendaCompromissos[], int *numCompromissos) {
    if (*numCompromissos < 50) {
        printf("Digite a data do compromisso (dd/mm/yyyy): ");
        fflush(stdin);
        scanf(" %[^\n]s", agendaCompromissos[*numCompromissos].data);
        printf("Digite a descrição do compromisso: ");
        fflush(stdin);
        scanf(" %[^\n]s", agendaCompromissos[*numCompromissos].descricao);
        (*numCompromissos)++;
    } else {
        printf("A agenda de compromissos está cheia.\n");
    }
}

void listarCompromissos(struct Compromisso agendaCompromissos[], int numCompromissos) {
    printf("\nLista de Compromissos:\n");
    for (int i = 0; i < numCompromissos; i++) {
        printf("Data: %s\n", agendaCompromissos[i].data);
        printf("Descrição: %s\n", agendaCompromissos[i].descricao);
        printf("\n");
    }
}
