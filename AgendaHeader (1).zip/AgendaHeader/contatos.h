#ifndef CONTATOS_H
#define CONTATOS_H

// Definir estruturas para contatos
struct Contato {
    char nome[50];
    char telefone[15];
};

void salvarContatosEmArquivo(const char *nomeArquivo, struct Contato agendaContatos[], int numContatos);
void carregarContatosDeArquivo(const char *nomeArquivo, struct Contato agendaContatos[], int *numContatos);
void listarContatos(struct Contato agendaContatos[], int numContatos);
void adicionarContato(struct Contato agendaContatos[], int *numContatos);

#endif // CONTATOS_H
