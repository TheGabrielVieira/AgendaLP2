#ifndef COMPROMISSOS_H
#define COMPROMISSOS_H

// Definir estruturas para compromissos
struct Compromisso {
    char data[11];
    char descricao[100];
};

void salvarCompromissosEmArquivo(const char *nomeArquivo, struct Compromisso agendaCompromissos[], int numCompromissos);
void carregarCompromissosDeArquivo(const char *nomeArquivo, struct Compromisso agendaCompromissos[], int *numCompromissos);
void listarCompromissos(struct Compromisso agendaCompromissos[], int numCompromissos);
void adicionarCompromisso(struct Compromisso agendaCompromissos[], int *numCompromissos);

#endif // COMPROMISSOS_H
