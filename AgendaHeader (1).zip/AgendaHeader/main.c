#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include "contatos.h"
#include "compromissos.h"
#include "pagamentos.h"
#include "gerenciaArq.h"

int main() {
    setlocale(LC_ALL, "Portuguese_Brazil");

    struct Contato agendaContatos[10];
    struct Compromisso agendaCompromissos[10];
    struct PagamentoRecebimento agendaPagamentos[10];
    int numContatos = 0, numCompromissos = 0, numPagamentos = 0;
    int escolha;

    // Verificar se os arquivos existem antes de carregar
    FILE *arquivoContatos = fopen("contatos.txt", "rb");
    if (arquivoContatos != NULL) {
        fclose(arquivoContatos);
        carregarDeArquivo("contatos.txt", agendaContatos, 10, sizeof(struct Contato));
        numContatos = 10; // Define numContatos para 1, para evitar a contagem incorreta de itens.
    }

    FILE *arquivoCompromissos = fopen("compromissos.txt", "rb");
    if (arquivoCompromissos != NULL) {
        fclose(arquivoCompromissos);
        carregarDeArquivo("compromissos.txt", agendaCompromissos, 10, sizeof(struct Compromisso));
        numCompromissos = 10; // Define numCompromissos para 1.
    }

    FILE *arquivoPagamentos = fopen("pagamentos.txt", "rb");
    if (arquivoPagamentos != NULL) {
        fclose(arquivoPagamentos);
        carregarDeArquivo("pagamentos.txt", agendaPagamentos, 10, sizeof(struct PagamentoRecebimento));
        numPagamentos = 10; // Define numPagamentos para 1.
    }

    // Carregar dados de arquivos (se existirem)
    carregarDeArquivo("contatos.txt", agendaContatos, 10, sizeof(struct Contato));
    carregarDeArquivo("compromissos.txt", agendaCompromissos, 10, sizeof(struct Compromisso));
    carregarDeArquivo("pagamentos.txt", agendaPagamentos, 10, sizeof(struct PagamentoRecebimento));

    do {
        puts("\t---------------");
        puts("\t-Agenda Boogle-");
        puts("\t---------------");
        puts("O que voc� quer fazer agora?");
        printf("1. Adicionar Contato\n");
        printf("2. Adicionar Compromisso\n");
        printf("3. Adicionar Pagamento/Recebimento\n");
        printf("4. Listar Contatos\n");
        printf("5. Listar Compromissos\n");
        printf("6. Listar Pagamentos/Recebimentos\n");
        printf("7. Sair\n");
        printf("Escolha uma op��o: ");
        fflush(stdin);
        scanf("%d", &escolha);
        getchar();
        switch (escolha) {
            case 1:
                adicionarContato(agendaContatos, &numContatos);
                salvarEmArquivo("contatos.txt", agendaContatos, numContatos, sizeof(struct Contato));
                break;
            case 2:
                adicionarCompromisso(agendaCompromissos, &numCompromissos);
                salvarEmArquivo("compromissos.txt", agendaCompromissos, numCompromissos, sizeof(struct Compromisso));
                break;
            case 3:
                adicionarPagamentoRecebimento(agendaPagamentos, &numPagamentos);
                salvarEmArquivo("pagamentos.txt", agendaPagamentos, numPagamentos, sizeof(struct PagamentoRecebimento));
                break;
            case 4:
                listarContatos(agendaContatos, numContatos);
                break;
            case 5:
                listarCompromissos(agendaCompromissos, numCompromissos);
                break;
            case 6:
                listarPagamentosRecebimentos(agendaPagamentos, numPagamentos);
                break;
            case 7:
                printf("\nSaindo da sua agenda.");
                break;
            default:
                printf("Op��o inv�lida.\n");
        }
    } while (escolha != 7);

    return 0;
}