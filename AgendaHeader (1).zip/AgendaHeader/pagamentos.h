#ifndef PAGAMENTOS_H
#define PAGAMENTOS_H

// Definir estruturas para pagamentos/recebimentos
struct PagamentoRecebimento {
    char data[11];
    char tipo[20];
    float valor;
};

void salvarPagamentosEmArquivo(const char *nomeArquivo, struct PagamentoRecebimento agendaPagamentos[], int numPagamentos);
void carregarPagamentosDeArquivo(const char *nomeArquivo, struct PagamentoRecebimento agendaPagamentos[], int *numPagamentos);
void listarPagamentosRecebimentos(struct PagamentoRecebimento agendaPagamentos[], int numPagamentos);
void adicionarPagamentoRecebimento(struct PagamentoRecebimento agendaPagamentos[], int *numPagamentos);

#endif // PAGAMENTOS_H
