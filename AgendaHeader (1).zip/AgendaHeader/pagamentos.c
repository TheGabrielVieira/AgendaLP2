#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pagamentos.h"

void listarPagamentosRecebimentos(struct PagamentoRecebimento agendaPagamentos[], int numPagamentos) {
    printf("\nLista de Pagamentos/Recebimentos:\n");
    for (int i = 0; i < numPagamentos; i++) {
        printf("Data: %s\n", agendaPagamentos[i].data);
        printf("Tipo: %s\n", agendaPagamentos[i].tipo);
        printf("Valor: %.2f\n", agendaPagamentos[i].valor);
        printf("\n");
    }
}

void adicionarPagamentoRecebimento(struct PagamentoRecebimento agendaPagamentos[], int *numPagamentos) {
    if (*numPagamentos < 50) {
        printf("Digite a data do pagamento/recebimento (dd/mm/yyyy): ");
        fflush(stdin);
        scanf(" %[^\n]s", agendaPagamentos[*numPagamentos].data);
        printf("Digite o tipo (Pagamento/Recebimento): ");
        fflush(stdin);
        scanf(" %[^\n]s", agendaPagamentos[*numPagamentos].tipo);
        printf("Digite o valor: ");
        fflush(stdin);
        scanf("%f", &agendaPagamentos[*numPagamentos].valor);
        (*numPagamentos)++;
    } else {
        printf("A agenda de pagamentos/recebimentos está cheia.\n");
    }
}
