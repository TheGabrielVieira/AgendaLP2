#ifndef GERENCIAARQ_H
#define GERENCIAARQ_H

void salvarEmArquivo(const char *nomeArquivo, void *dados, int numItens, size_t tamanhoItem);
void carregarDeArquivo(const char *nomeArquivo, void *dados, int numItens, size_t tamanhoItem);

#endif // GERENCIAARQ_H
