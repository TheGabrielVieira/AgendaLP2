#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gerenciaArq.h"

// Função para salvar contatos, compromissos e pagamentos/recebimentos em arquivos de texto
void salvarEmArquivo(const char *nomeArquivo, void *dados, int numItens, size_t tamanhoItem) {
    FILE *arquivo;
    arquivo = fopen(nomeArquivo, "wb");
    if (arquivo == NULL) {
        perror("Erro ao abrir arquivo");
        exit(1);
    }
    fwrite(dados, tamanhoItem, numItens, arquivo);
    fclose(arquivo);
}

// Função para carregar contatos, compromissos e pagamentos/recebimentos de arquivos de texto
void carregarDeArquivo(const char *nomeArquivo, void *dados, int numItens, size_t tamanhoItem) {
    FILE *arquivo;
    arquivo = fopen(nomeArquivo, "rb");
    if (arquivo == NULL) {
        perror("Erro ao abrir arquivo");
        exit(1);
    }
    fread(dados, tamanhoItem, numItens, arquivo);
    fclose(arquivo);
}
