#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

// Definir estruturas para contatos, compromissos e pagamentos/recebimentos
struct Contato {
    char nome[50];
    char telefone[15];
};

struct Compromisso {
    char data[11]; // Formato: dd/mm/yyyy
    char descricao[100];
};

struct PagamentoRecebimento {
    char data[11]; // Formato: dd/mm/yyyy
    char tipo[20]; // "Pagamento" ou "Recebimento"
    float valor;
};


// Fun��o para salvar contatos, compromissos e pagamentos/recebimentos em arquivos de texto
void salvarEmArquivo(const char *nomeArquivo, void *dados, int numItens, size_t tamanhoItem) {
    FILE *arquivo;
    arquivo = fopen(nomeArquivo, "wb");
    if (arquivo == NULL) {
        perror("Erro ao abrir arquivo");
        exit(1);
    }
    fwrite(dados, tamanhoItem, numItens, arquivo);
    fclose(arquivo);
}

// Fun��o para carregar contatos, compromissos e pagamentos/recebimentos de arquivos de texto
void carregarDeArquivo(const char *nomeArquivo, void *dados, int numItens, size_t tamanhoItem) {
    FILE *arquivo;
    arquivo = fopen(nomeArquivo, "rb");
    if (arquivo == NULL) {
        perror("Erro ao abrir arquivo");
        exit(1);
    }
    fread(dados, tamanhoItem, numItens, arquivo);
    fclose(arquivo);
}

// Fun��es para exibir itens da agenda
void listarContatos(struct Contato agendaContatos[], int numContatos) {
    printf("\nLista de Contatos:\n");
    for (int i = 0; i < numContatos; i++) {
        printf("Nome: %s\n", agendaContatos[i].nome);
        printf("Telefone: %s\n", agendaContatos[i].telefone);
        printf("\n");
    }
}

void listarCompromissos(struct Compromisso agendaCompromissos[], int numCompromissos) {
    printf("\nLista de Compromissos:\n");
    for (int i = 0; i < numCompromissos; i++) {
        printf("Data: %s\n", agendaCompromissos[i].data);
        printf("Descrição: %s\n", agendaCompromissos[i].descricao);
        printf("\n");
    }
}

void listarPagamentosRecebimentos(struct PagamentoRecebimento agendaPagamentos[], int numPagamentos) {
    printf("\nLista de Pagamentos/Recebimentos:\n");
    for (int i = 0; i < numPagamentos; i++) {
        printf("Data: %s\n", agendaPagamentos[i].data);
        printf("Tipo: %s\n", agendaPagamentos[i].tipo);
        printf("Valor: %.2f\n", agendaPagamentos[i].valor);
        printf("\n");
    }
}

// Fun��es para adicionar itens � agenda
void adicionarContato(struct Contato agendaContatos[], int *numContatos) {
    if (*numContatos < 50) {
        printf("Digite o nome do contato: ");
        fflush(stdin);
        scanf(" %[^\n]s", agendaContatos[*numContatos].nome);
        printf("Digite o telefone do contato: ");
        fflush(stdin);
        scanf(" %[^\n]s", agendaContatos[*numContatos].telefone);
        (*numContatos)++;
    } else {
        printf("A agenda de contatos está cheia.\n");
    }
}

void adicionarCompromisso(struct Compromisso agendaCompromissos[], int *numCompromissos) {
    if (*numCompromissos < 50) {
        printf("Digite a data do compromisso (dd/mm/yyyy): ");
        fflush(stdin);
        scanf(" %[^\n]s", agendaCompromissos[*numCompromissos].data);
        printf("Digite a descrição do compromisso: ");
        fflush(stdin);
        scanf(" %[^\n]s", agendaCompromissos[*numCompromissos].descricao);
        (*numCompromissos)++;
    } else {
        printf("A agenda de compromissos está cheia.\n");
    }
}

void adicionarPagamentoRecebimento(struct PagamentoRecebimento agendaPagamentos[], int *numPagamentos) {
    if (*numPagamentos < 50) {
        printf("Digite a data do pagamento/recebimento (dd/mm/yyyy): ");
        fflush(stdin);
        scanf(" %[^\n]s", agendaPagamentos[*numPagamentos].data);
        printf("Digite o tipo (Pagamento/Recebimento): ");
        fflush(stdin);
        scanf(" %[^\n]s", agendaPagamentos[*numPagamentos].tipo);
        printf("Digite o valor: ");
        fflush(stdin);
        scanf("%f", &agendaPagamentos[*numPagamentos].valor);
        (*numPagamentos)++;
    } else {
        printf("A agenda de pagamentos/recebimentos está cheia.\n");
    }
}

int main() {
    setlocale(LC_ALL, "Portuguese_Brazil");
    struct Contato agendaContatos[50];
    struct Compromisso agendaCompromissos[50];
    struct PagamentoRecebimento agendaPagamentos[50];
    int numContatos = 0, numCompromissos = 0, numPagamentos = 0;
    int escolha;

    // Verificar se os arquivos existem antes de carregar
    FILE *arquivoContatos = fopen("contatos.txt", "rb");
    if (arquivoContatos != NULL) {
        fclose(arquivoContatos);
        carregarDeArquivo("contatos.txt", agendaContatos, 50, sizeof(struct Contato));
        numContatos = 10; // Define numContatos para 1, para evitar a contagem incorreta de itens.
    }

    FILE *arquivoCompromissos = fopen("compromissos.txt", "rb");
    if (arquivoCompromissos != NULL) {
        fclose(arquivoCompromissos);
        carregarDeArquivo("compromissos.txt", agendaCompromissos, 50, sizeof(struct Compromisso));
        numCompromissos = 10; // Define numCompromissos para 1.
    }

    FILE *arquivoPagamentos = fopen("pagamentos.txt", "rb");
    if (arquivoPagamentos != NULL) {
        fclose(arquivoPagamentos);
        carregarDeArquivo("pagamentos.txt", agendaPagamentos, 50, sizeof(struct PagamentoRecebimento));
        numPagamentos = 10; // Define numPagamentos para 1.
    }

    // Carregar dados de arquivos (se existirem)
    carregarDeArquivo("contatos.txt", agendaContatos, 50, sizeof(struct Contato));
    carregarDeArquivo("compromissos.txt", agendaCompromissos, 50, sizeof(struct Compromisso));
    carregarDeArquivo("pagamentos.txt", agendaPagamentos, 50, sizeof(struct PagamentoRecebimento));

    do {
        puts("\t---------------");
        puts("\t-Agenda Boogle-");
        puts("\t---------------");
        puts("O que você quer fazer agora?");
        printf("1. Adicionar Contato\n");
        printf("2. Adicionar Compromisso\n");
        printf("3. Adicionar Pagamento/Recebimento\n");
        printf("4. Listar Contatos\n");
        printf("5. Listar Compromissos\n");
        printf("6. Listar Pagamentos/Recebimentos\n");
        printf("7. Sair\n");
        printf("Escolha uma opção: ");
        fflush(stdin);
        scanf("%d", &escolha);
        getchar();
        switch (escolha) {
            case 1:
                adicionarContato(agendaContatos, &numContatos);
                salvarEmArquivo("contatos.txt", agendaContatos, numContatos, sizeof(struct Contato));
                break;
            case 2:
                adicionarCompromisso(agendaCompromissos, &numCompromissos);
                salvarEmArquivo("compromissos.txt", agendaCompromissos, numCompromissos, sizeof(struct Compromisso));
                break;
            case 3:
                adicionarPagamentoRecebimento(agendaPagamentos, &numPagamentos);
                salvarEmArquivo("pagamentos.txt", agendaPagamentos, numPagamentos, sizeof(struct PagamentoRecebimento));
                break;
            case 4:
                listarContatos(agendaContatos, numContatos);
                break;
            case 5:
                listarCompromissos(agendaCompromissos, numCompromissos);
                break;
            case 6:
                listarPagamentosRecebimentos(agendaPagamentos, numPagamentos);
                break;
            case 7:
                printf("\nSaindo da sua agenda.");
                break;
            default:
                printf("Opção inválida.\n");
        }
    } while (escolha != 7);

    return 0;
}